import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'ngb-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  installPromptEvent;
  ngOnInit() {
    window.addEventListener('beforeinstallprompt', event => {
      this.installPromptEvent = event;
    });
  }

  installPWA() {
    this.installPromptEvent.prompt();
  }
}
